All used stored procedures can be found in queries folder

Requirements: 
Queries in queries folder,
Javascript
Node.js
node package mysql
node package sql
node package fs
node package express
node package path
All packages can be installed with "npm install 'package name'"

run the router/listener with app.js on the folder its contained in
Each query has its own .html page, however they all contain links to each other.
You can go through them in no particular order.

The refresh time for tables are static and 10 seconds more than the average time it took for queries to complete running.
If the table gets populated with null values, wait a few seconds, refresh, and try again.

IMPORTANT: the webpages are being accessed locally since there's no http server, which will result in
"Cross origin requests are only supported for protocol schemes: http, data, chrome, chrome-extension, https." error
unless CORS policy is disabled on chrome and firefox. If this is not disabled, tables won't load. data will still be stored in
data.json file. to allow file access:

you need to launch Chrome from a command prompt, specifying the --allow-file-access-from-files flag.