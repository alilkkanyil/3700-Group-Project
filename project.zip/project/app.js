/*########SERVER-SECTION########*/

//modules for webpage deployment...
var express=require('express');
var path=require('path');
// var router=express.Router();

var app=express();
app.use(express.static(path.join(__dirname,'/')));
app.use(express.urlencoded({extended: false}));
app.post('/voteRatings',function(request,result){
    voteRatings(request.body.rating,request.body.votes,request.body.adult,request.body.range);
    result.end();
});
app.post('/directors',function(request,result){
    directors(request.body.number,request.body.adult,request.body.range);
    result.end();
});
app.post('/topSeries',function(request,result){
    topSeries(request.body.season,request.body.adult,request.body.range);
    result.end();
});
app.post('/tvRange',function(request,result){
    tvRange(request.body.startYear,request.body.endYear,request.body.adult,request.body.range);
    result.end();
});
app.post('/allMoviesStaring',function(request,result){
    allMoviesStaring(request.body.actorOne,request.body.actorTwo,request.body.adult,request.body.range);
    result.end();
});

app.post('/differentRoles',function(request,result){
    differentRoles(request.body.adult,request.body.range);
    result.end();
});

app.post('/movieSearch',function(request,result){
    movieSearch(request.body.movie,request.body.adult,request.body.range);
    result.end();
});
app.post('/dead',function(request,result){
    dead(request.body.adult,request.body.range);
    result.end();
});

app.post('/notDead',function(request,result){
    notDead(request.body.adult,request.body.range);
    result.end();
});

app.post('/post_mortem',function(request,result){
    post_mortem(request.body.orderIN,request.body.adult,request.body.range);
    result.end();
});

app.post('/language_search',function(request,result){
    language_search(request.body.searchIN,request.body.orderIN,request.body.adult,request.body.range);
    result.end();
});

app.post('/genre_search',function(request,result){
    genre_search(request.body.searchIN,request.body.orderIN,request.body.adult,request.body.range);
    result.end();
});

app.listen(process.env.port||8080);

/*#######SQL-SECTION########*/
    
//module for mysql...
var mysql=require('mysql');
var fs=require('fs');
//functions for picking sql statement...
function voteRatings(rating,votes,adult,range){
    var sql="call rating_and_votes("+rating+","+votes+","+adult+","+range+")";
    getResult(sql);
};
function directors(number,adult,range){
    var sql="call directors("+number+","+adult+","+range+")";
    getResult(sql);
};

function topSeries(season,adult,range){
    var sql="call top_tv("+season+","+adult+","+range+")";
    getResult(sql);
};

function tvRange(startYear,endYear,adult,range){
    var sql="call tv_range("+startYear+","+endYear+","+adult+","+range+")";
    getResult(sql);
};

function allMoviesStaring(actorOne,actorTwo,adult,range){
    var sql="call two_actors('"+actorOne+"','"+actorTwo+"',"+adult+","+range+")";
    getResult(sql);
};

function differentRoles(adult,range){
    var sql="call multiple_roles("+adult+","+range+")";
    getResult(sql);
};

function movieSearch(movie,adult,range){
    var sql="call movie_search('"+movie+"',"+adult+","+range+")";
    getResult(sql);
};
function dead(adult,range){
    var sql="call dead("+adult+","+range+")";
    getResult(sql);
};
function notDead(adult,range){
    var sql="call notDead("+adult+","+range+")";
    getResult(sql);
};

function post_mortem(orderIN,adult,range){
    var sql="call post_mortem("+orderIN+","+adult+","+range+")";
    getResult(sql);
};

function language_search(searchIN,orderIN,adult,range){
    var sql="call language_search('"+searchIN+"',"+orderIN+","+adult+","+range+")";
    getResult(sql);
};

function genre_search(searchIN,orderIN,adult,range){
    var sql="call genre_search('"+searchIN+"',"+orderIN+","+adult+","+range+")";
    getResult(sql);
};

//Sends query to mysql, saves the result to data,
//  and generates a json file for the query results...
function getResult(sql){
    //module for mysql...
    //var mysql=require('mysql');
    //var fs=require('fs');
    //connects to mysql...
    var con=mysql.createConnection({
        host: "localhost",
        user: "root",
        password: "1234",
        database: "imdb4"
    });
        console.log("b");    
    con.connect(function(err) {
        if(err) throw err;
        con.query(sql, function (err,result,fields) {
          if (err) throw err;
          console.log(result);
          fs.writeFile(__dirname+'/data.json',JSON.stringify(result[0],null,2),function(err){
              if(err)throw err;
          });
        });
    });
};