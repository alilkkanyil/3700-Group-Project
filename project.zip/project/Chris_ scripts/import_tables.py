import mysql.connector
import time
import platform
from pathlib import Path
from math import ceil
from typing import Tuple

# Requires installation of the MySQL Python Connector available from https://dev.mysql.com/downloads/connector/python/.

WIN_PATH = 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads'
MAC_PATH = '/usr/local/var/mysql'
LINUX_PATH = '/usr/local/mysql/var'

IS_LOCAL = False

qappWriters = ('INSERT INTO Title_Writers VALUES (%s, %s);')
qappDirectors = ('INSERT INTO Title_Directors VALUES (%s, %s);')

qappLoadData = ('LOAD DATA INFILE \'{}\' INTO TABLE {} LINES TERMINATED BY \'\\n\' IGNORE 1 LINES;')
qappLoadLocalData = ('LOAD DATA LOCAL INFILE \'{}\' INTO TABLE {} LINES TERMINATED BY \'\\n\' IGNORE 1 LINES;')

TABLES = {}

TABLES['Title_Basics'] = ('CREATE TABLE Title_Basics (tconst VARCHAR(10) NOT NULL,'
                          'titleType VARCHAR(15),'
                          'primaryTitle VARCHAR(512),'
                          'originalTitle VARCHAR(512),'
                          'isAdult BOOLEAN,'
                          'startYear SMALLINT UNSIGNED,'
                          'endYear SMALLINT UNSIGNED,'
                          'runtimeMinutes MEDIUMINT UNSIGNED CHECK(runtimeMinutes >= 0),'
                          'genres VARCHAR(50),'
                          'Primary Key (tconst),'
                          'INDEX primaryTitle_idx (primaryTitle(25)),'
                          'INDEX originalTitle_idx (originalTitle(25)));')

TABLES['Name_Basics'] = ('CREATE TABLE Name_Basics (nconst VARCHAR(10) NOT NULL,'
                         'primaryName VARCHAR(120),'
                         'birthYear SMALLINT UNSIGNED,'
                         'deathYear SMALLINT UNSIGNED,'
                         'primaryProfession VARCHAR(100),'
                         'knownForTitles VARCHAR(100),'
                         'Primary Key (nconst),'
                         'INDEX name_idx (primaryName(10)));')

TABLES['Title_Akas'] = ('CREATE TABLE Title_Akas (titleId VARCHAR(10),'
                        'ordering TINYINT UNSIGNED,'
                        'title VARCHAR(1024),'
                        'region VARCHAR(4),'
                        'language VARCHAR(25),'
                        'types VARCHAR(25),'
                        'attributes VARCHAR(100),'
                        'isOriginalTitle BOOLEAN,'
                        'Primary Key (titleId,ordering),'
                        'Foreign Key (titleId) references Title_Basics (tconst),'
                        'INDEX title_idx (title(25)),'
                        'INDEX titleId_idx (titleId));')

TABLES['Title_Episode'] = ('CREATE TABLE Title_Episode (tconst VARCHAR(10) NOT NULL,'
                           'parentTconst VARCHAR(10) NOT NULL,'
                           'seasonNumber SMALLINT UNSIGNED CHECK(seasonNumber >= 0),'
                           'episodeNumber MEDIUMINT UNSIGNED CHECK(episodeNumber >= 0),'
                           'Primary Key (tconst, parentTconst),'
                           'Foreign Key (tconst) references Title_Basics (tconst),'
                           'Foreign Key (parentTconst) references Title_Basics (tconst),'
                           'INDEX tconst_idx (tconst),'
                           'INDEX parentTconst_idx (parentTconst));')

TABLES['Title_Directors'] = ('CREATE TABLE Title_Directors (tconst VARCHAR(10) NOT NULL,'
                             'nconst VARCHAR(10) NOT NULL,'
                             'Primary Key (tconst,nconst),'
                             'Foreign Key (tconst) references Title_Basics (tconst),'
                             'Foreign Key (nconst) references Name_Basics (nconst),'
                             'INDEX nconst_idx (nconst));')

TABLES['Title_Writers'] = ('CREATE TABLE Title_Writers (tconst VARCHAR(10) NOT NULL,'
                           'nconst VARCHAR(10) NOT NULL,'
                           'Primary Key (tconst,nconst),'
                           'Foreign Key (tconst) references Title_Basics (tconst),'
                           'Foreign Key (nconst) references Name_Basics (nconst),'
                           'INDEX nconst_idx (nconst));')

TABLES['Title_Principals'] = ('CREATE TABLE Title_Principals (tconst VARCHAR(10) NOT NULL,'
                              'ordering TINYINT UNSIGNED,'
                              'nconst VARCHAR(10) NOT NULL,'
                              'category VARCHAR(25),'
                              'job VARCHAR(300),'
                              'characters VARCHAR(512),'
                              'Primary Key (tconst,ordering),'
                              'Foreign Key (tconst) references Title_Basics (tconst),'
                              'Foreign Key (nconst) references Name_Basics (nconst),'
                              'INDEX tconst_idx (tconst),'
                              'INDEX nconst_idx (nconst));')

TABLES['Title_Ratings'] = ('CREATE TABLE Title_Ratings (tconst VARCHAR(10) NOT NULL,'
                           'averageRating NUMERIC(3,1) CHECK(averageRating BETWEEN 0.0 AND 10.0),'
                           'numVotes INT CHECK(numVotes > 0),'
                           'Primary Key (tconst),'
                           'Foreign Key (tconst) references Title_Basics (tconst),'
                           'INDEX tconst_idx (tconst));')

DROP_TABLES = {}

DROP_TABLES['Title_Akas'] = ('DROP TABLE IF EXISTS Title_Akas;')
DROP_TABLES['Title_Crew'] = ('DROP TABLE IF EXISTS Title_Crew;')
DROP_TABLES['Title_Episode'] = ('DROP TABLE IF EXISTS Title_Episode;')
DROP_TABLES['Title_Principals'] = ('DROP TABLE IF EXISTS Title_Principals;')
DROP_TABLES['Title_Ratings'] = ('DROP TABLE IF EXISTS Title_Ratings;')
DROP_TABLES['Title_Directors'] = ('DROP TABLE IF EXISTS Title_Directors;')
DROP_TABLES['Title_Writers'] = ('DROP TABLE IF EXISTS Title_Writers;')
DROP_TABLES['Name_Basics'] = ('DROP TABLE IF EXISTS Name_Basics;')
DROP_TABLES['Title_Basics'] = ('DROP TABLE IF EXISTS Title_Basics;')


def connect_to_mysql() -> Tuple[mysql.connector.MySQLConnection,mysql.connector.connection.MySQLCursorBuffered, str, str]:
    global IS_LOCAL

    user: str = input("user name (default = 'root'): ")
    if len(user) == 0:
        user = 'root'

    password: str = input("password (default = 'password'): ")
    if len(password) == 0:
        password = 'password'

    db: str = input("database (default = 'imdb'): ")
    if len(db) == 0:
        db = 'imdb'

    address: str = input("server address (default = 'localhost'): ")
    if len(address) == 0:
        address = 'localhost'

    dir_path: str = input(".tsv directory: ")
    if not Path(dir_path).exists() or len(dir_path) == 0:
        if platform.system() == 'Windows':
            dir_path = WIN_PATH
        elif platform.system() == 'OS X':
            dir_path = MAC_PATH
        else:
            dir_path = LINUX_PATH

    if dir_path in (WIN_PATH, MAC_PATH, LINUX_PATH):
        IS_LOCAL = False
    else:
        IS_LOCAL = True

    # Create a connection to the database on localhost
    # Change password to match your root password
    conn = mysql.connector.MySQLConnection(user=user, password=password, host=address, allow_local_infile=IS_LOCAL)

    # Create cursor
    cursor = conn.cursor(buffered=True)

    # Turn off MySQL Server binary logging for duration of script (has high IOPS cost)
    cursor.execute('SET sql_log_bin = OFF;')

    # Turn off flushing of transaction log after each commit
    cursor.execute('SET GLOBAL innodb_flush_log_at_trx_commit = 0;')

    # Turn off foreign key checks for duration of script
    cursor.execute('SET foreign_key_checks = 0;')

    # Increase size of buffer used for bulk inserts to 128MB
    cursor.execute('SET GLOBAL bulk_insert_buffer_size = 134217728;')

    # Explicitly start a transaction
    cursor.execute('START TRANSACTION;')

    return conn, cursor, dir_path, db


# Create main tables
def create_tables(cursor):
    if cursor:
        for key in TABLES:
            table_def = TABLES[key]
            print('Creating table', key, '...', end=' ')
            cursor.execute(table_def)
            print('complete!')


# Remove tables if they already exist
def drop_tables(cursor):
    if cursor:
        for key in DROP_TABLES:
            query = DROP_TABLES[key]
            print('Dropping table', key, '...', end=' ')
            cursor.execute(query)
            print('complete!')


# dir_path: absolute path to the directory where the .tsv files are located.
def create_path_dict(abs_path: str) -> dict:
    dir_path = Path(abs_path)
    paths = {}
    paths['Name_Basics'] = dir_path.joinpath('name.basics.tsv').as_posix()
    paths['Title_Basics'] = dir_path.joinpath('title.basics.tsv').as_posix()
    paths['Title_Akas'] = dir_path.joinpath('title.akas.tsv').as_posix()
    paths['Title_Episode'] = dir_path.joinpath('title.episode.tsv').as_posix()
    paths['Title_Principals'] = dir_path.joinpath('title.principals.tsv').as_posix()
    paths['Title_Ratings'] = dir_path.joinpath('title.ratings.tsv').as_posix()

    return paths


# Loads .tsv files using bulk import into temporary tables (Name_Basics and Title_Basics being the exceptions).
# dir_path: absolute path to the directory where the .tsv files are located.
def bulk_load_tables(dir_path: str, cursor):
    TSV_PATHS = create_path_dict(dir_path)

    if cursor:
        if TSV_PATHS:
            for key in TSV_PATHS:
                file_path = TSV_PATHS[key]
                print('Loading file', file_path, '...', end=' ')

                start = time.perf_counter()
                if IS_LOCAL:
                    cursor.execute(qappLoadLocalData.format(file_path, key))
                else:
                    cursor.execute(qappLoadData.format(file_path, key))
                end = time.perf_counter()

                print('complete!')
                print("Inserted", cursor.rowcount, "row(s) into", key, "in {0:.2f}".format(end - start), "secs.")


# Groups together multiple sets of record values for insert operations. Greatly speeds up inserts.
# inserts: a list of insert query strings
# step: the number of inserts to perform during a single query operation (total query size must be < 1 GB).
def batch_inserts(cursor, query: str, key: str, inserts: list, step: int):
    total = 0
    start = time.perf_counter()

    for i in range(ceil(len(inserts) / step)):
        cursor.executemany(query, inserts[i * step:i * step + step])
        total += cursor.rowcount
    end = time.perf_counter()

    print("Inserted", total, "row(s) into", key, "in {0:.2f}".format(end - start), "secs.")


# Loads individual writers or individual directors into a single row along with a title key in the imdb database.
# dir_path: absolute path to the directory where the title.crew.tsv file is located.
# step: the number of inserts to perform during a single query operation (total query size must be < 1 GB).
def import_crew(dir_path: str, cursor, step: int = 250):
    # List of title, writer tuples
    writer_list = []
    # List of title, director tuples
    director_list = []

    file_path = (Path(dir_path).joinpath('title.crew.tsv')).as_posix()
    print('Loading file', file_path, '...')

    # Read all records from Title_Crew file
    line_num = 0
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            if line_num > 0:
                line = line.rstrip('\n')
                temp = line.split('\t')
                tconst, directors, writers = temp[0], temp[1], temp[2]
                if directors != "\\N":
                    temp = directors.split(',')
                    for director in temp:
                        director_list.append((tconst, director))

                if writers != "\\N":
                    temp = writers.split(',')
                    for writer in temp:
                        writer_list.append((tconst, writer))
            line_num += 1

    batch_inserts(cursor, qappWriters, 'Title_Writers', writer_list, step)
    batch_inserts(cursor, qappDirectors, 'Title_Directors', director_list, step)


def close_connection(cursor, conn):
    # Turn on binary logging
    cursor.execute('SET sql_log_bin = ON;')

    # Turn on flushing of transaction log after each commit
    cursor.execute('SET GLOBAL innodb_flush_log_at_trx_commit = 1;')

    # Turn off foreign key checks for duration of script
    cursor.execute('SET foreign_key_checks = 1;')

    # Increase size of buffer used for bulk inserts to 64MB
    cursor.execute('SET GLOBAL bulk_insert_buffer_size = 8388608;')

    # Close connection
    cursor.close()
    conn.close()


# imports .tsv files into imdb database schema
# dir_path: absolute path to the directory where the .tsv files are located
# db: name of an existing database where tables will be created or an existing database
# user: mysql instance login user name
# password: mysql instance login user password
def import_imdb():
    start = time.perf_counter()

    # Create a connection to the database on localhost
    conn, cursor, dir_path, db = connect_to_mysql()

    # Create database and set it as default
    cursor.execute('CREATE DATABASE IF NOT EXISTS {};'.format(db))
    cursor.execute('USE {};'.format(db))

    # Remove tables if they already exist
    drop_tables(cursor)

    create_tables(cursor)

    bulk_load_tables(dir_path, cursor)

    import_crew(dir_path, cursor, 50)

    # InnoDB uses transactions by default, so commit changes if no errors
    conn.commit()

    # Clean up and close the connection to MySQL Server
    close_connection(cursor, conn)

    end = time.perf_counter()
    print('Finished in {0:.1f} seconds.'.format(end - start))


import_imdb()
