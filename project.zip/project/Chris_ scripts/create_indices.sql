USE imdb;

CREATE INDEX seasonnumber_idx
ON Title_Episode (seasonNumber);

CREATE INDEX birthyear_idx
ON Name_Basics (birthYear);

CREATE INDEX name_idx
ON Name_Basics (primaryName);

CREATE INDEX category_idx
ON Title_Principals (category);

CREATE INDEX title_idx
ON Title_Basics (titleType);

CREATE INDEX startyear_idx
ON Title_Basics (startYear);

CREATE INDEX endyear_idx
ON Title_Basics (endYear);

CREATE INDEX region_idx
ON Title_Akas (region);
