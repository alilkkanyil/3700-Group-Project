DELIMITER //
CREATE procedure top_tv(IN seasonIN int, IN orderIN bool, IN adultIN bool, IN rangeIN int)
BEGIN
   SELECT DISTINCT primaryTitle FROM Title_Basics 
	INNER JOIN Title_Episode ON Title_Basics.tconst = Title_Episode.parentTconst
	INNER JOIN Title_Ratings ON Title_Basics.tconst = Title_Ratings.tconst
	WHERE Title_Basics.tconst IN (SELECT parentTconst FROM Title_Episode WHERE seasonNumber > seasonIN) AND Title_Basics.titleType = 'tvSeries' AND title_basics.isAdult = adultIN
	ORDER BY averageRating DESC
	LIMIT rangeIN, 50;
END//