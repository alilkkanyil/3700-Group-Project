DELIMITER //
CREATE procedure language_search(IN searchIN varchar(512), IN orderIN bool, IN adultIN bool, IN rangeIN int)
BEGIN
		SELECT * FROM Title_Basics
		INNER JOIN Title_Akas ON Title_Basics.tconst = Title_Akas.titleID
		WHERE Title_Akas.language like searchIN and title_basics.isAdult = adultIN
        group by title_basics.primaryTitle
        ORDER BY 
		CASE orderIN WHEN 0 then startYear END DESC,
        CASE orderIN WHEN 1 then startYear END ASC;
        END;
		limit rangeIN, 50;
END//