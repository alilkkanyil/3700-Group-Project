DELIMITER //

CREATE procedure directors
(IN numberIN int, IN adultIN bool, IN rangeIN int)
BEGIN
	SELECT DISTINCT primaryName from Name_Basics
	INNER JOIN title_directors ON name_basics.nconst = title_directors.nconst
	WHERE (SELECT COUNT(title_directors.tconst) 
	FROM title_directors INNER JOIN title_basics 
	ON title_basics.tconst = title_directors.tconst 
	WHERE title_basics.titleType = 'movie' and title_basics.isAdult = adultIN) > numberIN
    LIMIT rangeIN, 50; 
END//