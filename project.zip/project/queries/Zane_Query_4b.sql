DELIMITER //
CREATE procedure two_actors(IN actor1IN varchar(120), IN actor2IN varchar(120),  IN orderIN bool, IN adultIN bool, IN rangeIN int)
BEGIN
	SELECT * FROM Title_Basics
	INNER JOIN Title_Principals ON Title_Basics.tconst = Title_Principals.tconst
	INNER JOIN Name_Basics ON Title_Principals.nconst = Name_Basics.nconst
	WHERE Title_Principals.category = 'actor' AND Name_Basics.primaryName like concat('%', actor1IN, '%') and Title_Basics.titleType = 'movie' and title_basics.isAdult = adultIN

	UNION

	SELECT * FROM Title_Basics
	INNER JOIN Title_Principals ON Title_Basics.tconst = Title_Principals.tconst
	INNER JOIN Name_Basics ON Title_Principals.nconst = Name_Basics.nconst
	WHERE Title_Principals.category = 'actor' AND Name_Basics.primaryName like concat('%', actor2IN, '%') and Title_Basics.titleType = 'movie' and title_basics.isAdult = adultIN;
END//