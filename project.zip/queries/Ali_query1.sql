DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `notDead`(IN adultIN bool, IN rangeIN int)
BEGIN
	SELECT * FROM name_basics
    INNER JOIN title_directors ON name_basics.nconst = title_directors.nconst
    WHERE deathYear is null
    LIMIT rangeIN, 50;
END //
