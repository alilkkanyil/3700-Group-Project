DELIMITER //
CREATE procedure tv_range(IN startIN int, IN endIN int,  IN orderIN bool, IN adultIN bool, IN rangeIN int)
BEGIN
	SELECT COUNT(Title_Episode.tconst) AS episodeCount,Title_Basics.*, region FROM Title_Basics 
	INNER JOIN Title_Akas ON Title_Basics.tconst = Title_Akas.titleId
	INNER JOIN Title_Episode ON Title_Basics.tconst = Title_Episode.parentTconst
	WHERE Title_Basics.titleType = 'tvSeries' AND (Title_Basics.startYear BETWEEN startIN AND endIN) AND region IS NOT NULL AND title_basics.isAdult = adultIN
	GROUP BY primaryTitle
	ORDER BY region ASC, primaryTitle ASC, episodeCount DESC
	limit rangeIN, 50;
END//