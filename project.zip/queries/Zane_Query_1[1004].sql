DELIMITER //
CREATE procedure rating_and_votes(IN ratingIN decimal(3,1),IN votesIN int,IN orderIN bool,IN adultIN bool,IN rangeIN int)
BEGIN
	SELECT primaryTitle as Title, region as Region, language as Language, startYear as Year, averageRating as Rating, numVotes as Votes
	FROM Title_Basics 
	INNER JOIN Title_Akas ON Title_Basics.tconst = Title_Akas.titleId 
	INNER JOIN Title_Ratings ON Title_Basics.tconst = Title_Ratings.tconst
	WHERE averageRating > ratingIN AND numVotes > votesIN AND isAdult = adultIN
	GROUP BY primaryTitle, startYear, averageRating, numVotes
    ORDER BY 
		CASE orderIN WHEN 0 then Rating END DESC,
        CASE orderIN WHEN 1 then Rating END ASC;
        END;
    LIMIT rangeIN, 50;
END//
DELIMITER ;