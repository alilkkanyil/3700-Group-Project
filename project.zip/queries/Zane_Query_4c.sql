DELIMITER //
CREATE procedure multiple_roles( IN orderIN bool, IN adultIN bool, IN rangeIN int)
BEGIN
	 SELECT * FROM Name_Basics
INNER JOIN Title_Principals ON Name_Basics.nconst = Title_Principals.nconst
INNER JOIN Title_Basics ON Title_Principals.tconst = Title_Basics.tconst
WHERE Name_Basics.nconst IN (SELECT nconst FROM Title_Principals WHERE category = 'actor' AND (char_length(characters) - char_length(replace(characters,',\"','\"'))) >= 2 AND titleType = 'movie') and title_basics.isAdult = adultIN;
END//