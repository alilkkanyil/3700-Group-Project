DELIMITER //
CREATE procedure movie_search(IN searchIN varchar(512), IN orderIN bool, IN adultIN bool, IN rangeIN int)
BEGIN
		SELECT * FROM Title_Basics
		INNER JOIN Title_Akas ON Title_Basics.tconst = Title_Akas.titleID
		WHERE Title_Basics.primaryTitle like concat('%', searchIN, '%') and title_basics.isAdult = adultIN
        group by title_basics.primaryTitle;

END//