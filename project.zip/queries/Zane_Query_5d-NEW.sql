DELIMITER //
CREATE procedure post_mortem( IN orderIN bool, IN adultIN bool, IN rangeIN int)
BEGIN
		SELECT * FROM Title_Basics
		INNER JOIN Title_Principals ON Title_Basics.tconst = Title_Principals.tconst
		INNER JOIN Name_Basics ON Title_Principals.nconst = Name_Basics.nconst
		WHERE Title_Principals.category = 'actor' AND Name_Basics.deathyear <= title_basics.startYear and Title_Basics.titleType = 'movie' and title_basics.isAdult = adultIN
        ORDER BY 
		CASE orderIN WHEN 0 then startYear END DESC,
        CASE orderIN WHEN 1 then startYear END ASC;
        END;
		limit rangeIN, 50;
END//