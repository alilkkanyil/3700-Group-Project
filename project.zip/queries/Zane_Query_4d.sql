DELIMITER //
CREATE procedure actor_born(IN startIN int, IN endIN int,  IN orderIN bool, IN adultIN bool, IN rangeIN int)
BEGIN
    case 
		 when orderIN = 0 then select name_basics.primaryName as Name, name_basics.birthYear as Born, count(distinct A.tconst) as Number_of_Roles
	from (select * from title_principals ) as A
	inner join name_basics on A.nconst = name_basics.nconst 
    where birthYear between startIN and endIN  and  Title_Principals.category = 'actor' or 'actress'
	group by Name
	ORDER BY Number_of_Roles DESC
    LIMIT rangeIN, 50;
		 else  select name_basics.primaryName as Name, name_basics.birthYear as Born, count(distinct A.tconst) as Number_of_Roles
	from (select * from title_principals ) as A
	inner join name_basics on A.nconst = name_basics.nconst 
    where birthYear between startIN and endIN and Title_Principals.category = 'actor' or 'actress'
	group by Name
	ORDER BY Number_of_Roles ASC
    LIMIT rangeIN, 50;
	 end case;
END//

DELIMITER ;